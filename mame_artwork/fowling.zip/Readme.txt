Disclaimer: I'm fine if you print this fan art for personal use, but I don't agree to it being sold in any form.

Credits initial gnw_mmouse art by :
Design, layout and editing by Lee Robson (hydef)
Background scans by Henrik Algestam

Credits changing art to fowling by :
Editing by Folkert van der Meulen (folly)
Background scans by "unknown"